﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class toTouristTG : MonoBehaviour {

	public void GoToTourist()
     {
         SceneManager.LoadScene(1);
     }
	
	public void GoToTourGuide()
     {
         SceneManager.LoadScene(2);
     }
	// Update is called once per frame
	void Update () {
		
	}
}
