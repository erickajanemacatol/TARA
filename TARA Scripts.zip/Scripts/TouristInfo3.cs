﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TouristInfo3 : MonoBehaviour {

	public string age;
	public GameObject inputField3;
	public GameObject textDisplay3;
	
	public void storeAge()
	{
		age = inputField3.GetComponent<Text>().text;
		textDisplay3.GetComponent<Text>().text = "Age: " + age;
	
	}
	
}

