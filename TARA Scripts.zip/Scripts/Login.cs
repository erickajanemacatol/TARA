﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Login : MonoBehaviour {

	public string username1;
	public GameObject inputField8;
	public GameObject textDisplay8;
	
	public void storeUN()
	{
		username1 = inputField8.GetComponent<Text>().text;
		textDisplay8.GetComponent<Text>().text = " Username: " + username1;
	
	}
	
}

