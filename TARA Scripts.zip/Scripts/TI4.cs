﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TI4 : MonoBehaviour {

	public string Gender;
	public GameObject dropDown;
	public GameObject textDisplay4;
	
	public void storeGender()
	{
		Gender = dropDown.GetComponent<Text>().text;
		textDisplay4.GetComponent<Text>().text = "Gender: " + Gender;
	
	}
	
}

