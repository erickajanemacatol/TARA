﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TI7 : MonoBehaviour {

	public string username;
	public GameObject inputField7;
	public GameObject textDisplay7;
	
	public void storeUN()
	{
		username = inputField7.GetComponent<Text>().text;
		textDisplay7.GetComponent<Text>().text = " Username: " + username;
	
	}
	
}

