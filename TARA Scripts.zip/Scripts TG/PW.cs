﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PW : MonoBehaviour {

	public string pass;
	public GameObject inputField5;
	public GameObject textDisplay5;
	
	public void storePass()
	{
		pass = inputField5.GetComponent<Text>().text;
		textDisplay5.GetComponent<Text>().text = pass;
	
	}
	
}


