﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gender : MonoBehaviour {

	public string gender;
	public GameObject inputField4;
	public GameObject textDisplay4;
	
	public void storeAge()
	{
		gender = inputField4.GetComponent<Text>().text;
		textDisplay4.GetComponent<Text>().text = gender;
	
	}
	
}

