﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LName : MonoBehaviour {

	public string lname;
	public GameObject inputField2;
	public GameObject textDisplay2;
	
	public void lName()
	{
		lname = inputField2.GetComponent<Text>().text;
		textDisplay2.GetComponent<Text>().text = lname;
	
	}
	
}

