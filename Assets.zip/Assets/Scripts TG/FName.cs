﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FName : MonoBehaviour {

	public string fname;
	public GameObject inputField;
	public GameObject textDisplay;
	
	public void fName()
	{
		fname = inputField.GetComponent<Text>().text;
		textDisplay.GetComponent<Text>().text = fname
		;
	
	}
	
}

