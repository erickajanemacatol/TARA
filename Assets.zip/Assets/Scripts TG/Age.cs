﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Age : MonoBehaviour {

	public string age;
	public GameObject inputField;
	public GameObject textDisplay;
	
	public void storeAge()
	{
		age = inputField.GetComponent<Text>().text;
		textDisplay.GetComponent<Text>().text = age;
	
	}
	
}

