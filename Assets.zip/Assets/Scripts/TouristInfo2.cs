﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TouristInfo2 : MonoBehaviour {

	public string lastName;
	public GameObject inputField;
	public GameObject textDisplay;
	
	
	public void storelastName()
	{
		lastName = inputField.GetComponent<Text>().text;
		textDisplay.GetComponent<Text>().text = lastName;
	
	}
	
}

