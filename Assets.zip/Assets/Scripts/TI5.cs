﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TI5 : MonoBehaviour {

	public string Contact;
	public GameObject inputField5;
	public GameObject textDisplay5;
	
	public void storeNumber()
	{
		Contact = inputField5.GetComponent<Text>().text;
		textDisplay5.GetComponent<Text>().text = "Contact Number: " + Contact;
	
	}
	
}

