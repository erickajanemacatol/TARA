﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TI6 : MonoBehaviour {

	public string email;
	public GameObject inputField6;
	public GameObject textDisplay6;
	
	public void storeNumber()
	{
		email = inputField6.GetComponent<Text>().text;
		textDisplay6.GetComponent<Text>().text = " Email: " + email;
	
	}
	
}

